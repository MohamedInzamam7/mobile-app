package com.example.ocr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
